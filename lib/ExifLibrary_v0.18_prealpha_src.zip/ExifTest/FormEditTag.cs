﻿using System;
using System.Windows.Forms;

namespace ExifLibrary
{
    public partial class FormEditTag : Form
    {
        public FormEditTag()
        {
            InitializeComponent();
        }
    }
}
